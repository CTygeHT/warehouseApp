create procedure addMixingOrder(IN pantName smallint(10), IN sum decimal(7, 3), IN warehouse smallint(10))
  Begin

set @docnumber = (select max(id_doc) + 1 from poli_farb.transactions);

insert into transactions 
select null, @docnumber, warehouse, warehouse, id_tmc_comp, portion * sum / -100 , now() 
from poli_farb.formula 
where id_tmc_prod = pantName;

insert into transactions values (null, @docnumber, warehouse, warehouse, pantName, sum, now());

End;

