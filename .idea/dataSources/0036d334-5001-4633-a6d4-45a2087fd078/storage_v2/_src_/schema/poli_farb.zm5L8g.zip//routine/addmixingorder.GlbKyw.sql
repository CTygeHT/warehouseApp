create procedure addMixingOrder(IN pantName smallint(10), IN sum decimal(7, 3))
  Begin

set @docnumber = (select max(id_doc) + 1 from poli_farb.transactions);

insert into transactions 
select null, @docnumber, id_s, id_s, id_tmc_comp, portion * sum / -100 , now() 
from poli_farb.formula 
where id_tmc_prod = pantName;

set @docnumber = (select max(id_doc) + 1 from poli_farb.transactions);
set @store = (select distinct id_s from poli_farb.formula where id_tmc_prod = pantName);

insert into transactions values (null, @docnumber, @store, @store, pantName, sum, now());

End;

