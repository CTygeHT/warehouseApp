create procedure get_balance(IN id_ss smallint(1), IN id_tt smallint(10), IN DateT datetime)
  Begin

Select 
s.id_s, s.id_tmc, (cur_leftover - ifnull(sum(amount), 0)) as balance_on_date

From store s
left join transactions t on s.id_s=t.id_s
                and s.id_tmc=t.id_tmc
                and date_time>=dateT

Where 
    t.id_s=id_ss
    and t.id_tmc=id_tt;
End;

