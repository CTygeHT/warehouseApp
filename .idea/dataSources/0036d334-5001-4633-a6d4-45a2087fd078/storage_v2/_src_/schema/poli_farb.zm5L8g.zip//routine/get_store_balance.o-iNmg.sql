create procedure get_store_balance(IN id_ss smallint(1), IN DateT datetime)
  Begin

Select 
s.id_s, s.id_tmc, (cur_leftover + ifnull(sss, 0)) as balance_on_date

From store s
left join 
(select id_s, t.id_tmc, sum(amount) as sss from transactions t where date_time>=dateT group by id_s, t.id_tmc) as tt

   on s.id_s=tt.id_s
                and s.id_tmc=tt.id_tmc
                

Where 
    s.id_s=id_ss;
End;

