create trigger tmc_AFTER_INSERT
  after INSERT
  on tmc
  for each row
  BEGIN
set @tmc = (SELECT id_tmc from tmc where name_tmc = NEW.name_tmc);
insert into store values(1, @tmc, 0);
insert into store values(2, @tmc, 0);
insert into store values(3, @tmc, 0);
END;

