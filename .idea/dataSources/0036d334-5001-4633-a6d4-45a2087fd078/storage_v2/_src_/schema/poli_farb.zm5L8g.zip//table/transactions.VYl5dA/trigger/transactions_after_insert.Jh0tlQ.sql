create trigger transactions_AFTER_INSERT
  after INSERT
  on transactions
  for each row
  BEGIN
  set @warehouse = (select t.id_s from poli_farb.transactions t where t.id_trans = (SELECT Max(id_trans) from poli_farb.transactions)),
  @tmc = (select t.id_tmc from poli_farb.transactions t where t.id_trans = (SELECT Max(id_trans) from poli_farb.transactions));
  if (SELECT NOT EXISTS(SELECT id_tmc FROM poli_farb.store WHERE id_tmc = @tmc and id_s = @warehouse)) THEN 
  insert into poli_farb.store values (@warehouse, @tmc, 0);
  end if;
  UPDATE store s, transactions t	
  set cur_leftover = cur_leftover + amount 
  where s.id_s = t.id_s and s.id_tmc = t.id_tmc and t.id_trans = (SELECT Max(id_trans) FROM transactions);
END;

